#include <iostream>

using namespace std;

int main(){
	
	// char arr[] = "Lauchpad";
	// string str = "Lauchpad";

	// cout<<str.length()<<endl;
	// cout<<sizeof(arr)<<endl;

	// cout<<sizeof(str)<<endl;

	// // cin>>str;

	// // cout<<str<<endl;

	// cout<<sizeof(str[4])<<endl;

	// for(int i=0;i<str.length();i++){
	// 	cout<<str[i]<<endl;
	// }

	// cout<<str<<endl;
	// string result = str.substr(2,3);
	// cout<<result<<endl;

	// string brr[] = {"bat","apple","deadpool","captain"};
	// sort(brr,brr+4);

	// for(int i=0;i<4;i++){
	// 	cout<<brr[i]<<" ";
	// }
	// cout<<endl;

	//*************************

	string s = "coding" + (string)"blocks";
	cout<<s<<endl;

	string first = "coding";
	string second = "blocks";

	cout<<(first + second)<<endl;

	cout<<(first + "blocks")<<endl;

	// char ch = 'a';
	// string test = "pranav";
	// string str = test + ch;
	// cout<<str<<endl;

	return 0;
}
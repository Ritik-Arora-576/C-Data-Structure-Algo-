#include <iostream>

using namespace std;

int main(){

	// int a = 10;
	// float b = 12;
	// char c = 65;
	// bool d = 12;

	// cout<<"Integer value is "<<a<<endl;
	// cout<<"Float value is "<<b<<endl;
	// cout<<"Character value is "<<c<<endl;
	// cout<<"Boolean value is "<<d<<endl;

	// bool hawa = false;

	// bool friends = false; 

	// if(false){
	// 	cout<<"AFSOS"<<endl;

	// }else{
	// 	// cout<<"KHELO"<<endl;

	// 	if('p'){
	// 		cout<<"KHELO"<<endl;
	// 	}else{
	// 		cout<<"BOHOT AFSOS"<<endl;
	// 	}
	// }


	// Operations

	

	return 0;
}
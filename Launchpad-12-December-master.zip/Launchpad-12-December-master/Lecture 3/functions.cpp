#include <iostream>

using namespace std;

int square(int a){

    return a*a;
}

int main(){

	cout<<square(3)<<endl;

	int a = 10;

	cout<<(a*a)<<endl;

	cout<<a<<endl;

    return 0;
}
#include <iostream>

using namespace std;

int main(){

	// cout<<(5^7)<<endl;
	// cout<<(5&7)<<endl;
	// cout<<(5|7)<<endl;

	// int n = 9;
	// cout<<(n>>2)<<endl;
	// cout<<(n>>1)<<endl;

	// cout<<n<<endl;

	// cout<<(n<<1)<<endl;
	// cout<<(n<<2)<<endl;

	cout<<(5^5^7)<<endl; // 7
	cout<<(7^5^5)<<endl; // 0
	cout<<(5^7^5)<<endl; // 7

	return 0;
}
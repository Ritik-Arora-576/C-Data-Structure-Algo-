#include <iostream>

using namespace std;

int main(){

	// i = i + 1 -> i++;

	int i = 0;

	cout<<"For Loop"<<endl;	
	for(;i<=5;){

		cout<<i<<" ";


		i++;

		cout<<i<<endl;
	}
	cout<<endl;

	cout<<"While Loop"<<endl;

	int p = 0;

	while(p<=5){

		cout<<p<<" ";

		p++;

		cout<<p<<endl;
	}

	for(int x = 0;x<=5;x++){


		
	}

	return 0;
}
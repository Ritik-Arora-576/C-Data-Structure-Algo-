#include <iostream>

using namespace std;

int main(){

	int a = 2;
	char c = 'a';

	bool b = 4;

	// cout<<(c+a)<<endl;

	// cout<<(c+b)<<endl;

	bool p = c + 3;

	// cout<<c<<endl;

	cout<<p<<endl;

	return 0;
}
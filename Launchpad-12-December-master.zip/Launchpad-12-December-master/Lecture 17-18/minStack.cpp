#include <iostream>

using namespace std;

class MinStack{

};

int main(){



	return 0;
}
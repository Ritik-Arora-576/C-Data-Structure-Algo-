#include <iostream>

using namespace std;

int main(){

	int p,r,t;

	cout<<"Enter P"<<endl;
	cin>>p;

	cout<<"Enter R"<<endl;
	cin>>r;

	cout<<"Enter T"<<endl;
	cin>>t;

	int si = p*r*t/100;

	// cout<<"Simple Interest is "<<si<<endl;
	// cout<<"Simple Interest is "<<(p*r*t/100)<<endl;

	return 0;
}
#include <iostream>

using namespace std;

int main(){

	int hawa = 0;

	int friends = 12;

	if(hawa!=true and friends){
		cout<<"KHELO"<<endl;
	}

	return 0;
}
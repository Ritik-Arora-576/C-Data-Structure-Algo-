#include <iostream>

using namespace std;

int main(){

	int i = 7; //starting point

	while(i<=10 and i>=1){ //barrier
		cout<<"Number is "<<i<<endl;
		i = i -1;
	}

	return 0;
}